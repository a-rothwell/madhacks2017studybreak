
window.location = "http://www.reddit.com"

//
/*
"content_scripts": [
      {
      "matches": ["https://www.google.com/*"],
      "js": ["redirect.js"],
      "run_at": "document_end"
      }
  ],
